`timescale 1ns/1ps

module misps_tb;

  // Testbench signals
  reg clk, reset, jump;
  reg [4:0] current_addr;

  // DUT instantiation
  misps uut (
    .clk(clk),
    .jump(jump),
    .reset(reset),
    .current_addr(current_addr)
  );

  // Clock generation (10ns period)
  initial begin
    clk = 0;
    forever #5 clk = ~clk;   // toggle every 5ns → 10ns period
  end

  // Stimulus
  initial begin
    // Initialize
    reset = 1;
    jump  = 0;
    current_addr = 5'b00000;

    // Hold reset for 2 cycles
    #20;
    reset = 0;

    // Let program run normally for some cycles
    #100;

    // Trigger a jump to address 5
    jump = 1;
    current_addr = 5'b00101;   // Jump to instruction 5
    #10;
    jump = 0;

    // Run more cycles to observe behavior
    #100;

    // Finish simulation
    $finish;
  end

  // Waveform dump
  initial begin
    $dumpfile("misps_tb.vcd");  // GTKWave / viewer
    $dumpvars(0, misps_tb);
  end

endmodule
